//
//  RootViewController.h
//  CropImageClass
//
//  Created by FaceUI on 13-6-18.
//  Copyright (c) 2013年 faceUI_anyi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YACropImage.h"
@interface RootViewController : UIViewController
@property (strong, nonatomic) YACropImage *cropImage;

@end
